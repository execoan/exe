### Jupyter notebooks for solving physics problems

This folder contains an assortment of code I have written over the years. Each subfolder corresponds to the year in which the code was first written. So please dig into these subfolders to find what you may like!

Some of these notebooks have been made into [blogs](https://rajeshrinet.github.io/blog/).
